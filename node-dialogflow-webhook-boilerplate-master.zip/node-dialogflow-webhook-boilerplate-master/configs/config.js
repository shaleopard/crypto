'use strict'

const config = {
  PORT: 8080
}

module.exports = config